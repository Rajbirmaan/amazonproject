package pomPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import basepackage.baeAmazon;



public class PomLogin extends baeAmazon{
	@FindBy(id="#ap_email")
	WebElement email;
	
@FindBy(id="continue")
WebElement btncontinue;

@FindBy(id="ap_password")
WebElement password;

@FindBy(id="signInSubmit")
WebElement btnSignin;

@FindBy(id="ap_customer_name")
WebElement yourname;

@FindBy(id="ap_email")
WebElement youremail;

@FindBy(id="ap_password_check")
WebElement passwordagain;

@FindBy(id="ap_password")
WebElement yourpassword;

@FindBy(id="continue")
WebElement btncontinue2;

@FindBy(css="#orderTypeMenuContainer > ul > li.selected > span > span")
WebElement cancelledorder;

@FindBy(css="#CardInstanceVbguOE8zxEIuzPNl_1L3Uw > div > div:nth-child(3) > ul > li._buy-again-tabs-desktop_searchAndYoStyle_tab-list-item__24Jay._buy-again-tabs-desktop_searchAndYoStyle_selected__3kNYk > span")
WebElement buyagain;

@FindBy(css="#CardInstanceVbguOE8zxEIuzPNl_1L3Uw > div > div:nth-child(3) > ul > li:nth-child(3) > span > a")
WebElement notyetshipped;


@FindBy(css="#address-ui-widgets-countryCode > span > span")
WebElement choosecity;

@FindBy(id="address-ui-widgets-enterAddressFullName")
WebElement fullname;

@FindBy(id="address-ui-widgets-enterAddressPhoneNumber")
WebElement mobilenumber;

@FindBy(id="address-ui-widgets-enterAddressPostalCode")
WebElement postalcode;

@FindBy(id="address-ui-widgets-enterAddressLine1")
WebElement houseno;


private WebDriver driver;

public PomLogin() {
	PageFactory.initElements(driver,this);
}
public void typeemail(String mail) {
	email.sendKeys(mail);
	
	
}
public void clickbtn() {
	btncontinue.click();
}
public void typepassword(String pass) {
	password.sendKeys(pass);
}
public void clickbtn2() {
	btnSignin.click();
	
}
public void typename(String name) {
	yourname.sendKeys(name);
}
public void typeyouremail(String email)
{
	youremail.sendKeys(email);
}
public void typeyourpassword(String yourpass) {
	yourpassword.sendKeys(yourpass);
}

public void typepasswordagain(String againpass) {
	passwordagain.sendKeys(againpass);
}
public void Clickbtn3() {
	btncontinue2.click();
}
public void checkCancelled() {
	cancelledorder.click();
}
public void checkbuyagain() {
	buyagain.click();
}
public void Checknotyetshipped() {
	notyetshipped.click();
}
	public void Selectcity(String city) {
	choosecity.sendKeys(city);
	}
	public void typeyourname(String fllname) {
		fullname.sendKeys(fllname);
	}
	public void typemobilenumber(String num) {
		mobilenumber.sendKeys(num);
	}
	public void typepostalcode(String code)
	{
		postalcode.sendKeys(code);
	}
	public void enterhouseno(String no) {
		houseno.sendKeys(no);
	}
	
}

