package testlayer;

import static org.testng.Assert.assertEquals;


import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import basepackage.baeAmazon;
import pomPackage.PomLogin;


public class Logintest extends baeAmazon{
	PomLogin log;
	public Logintest() {
		super();
	}
	@BeforeMethod
	public void initSetup() {
		initiate();
		log = new PomLogin();
	}
	@Test
	public void signIN() {
		log.typeemail(prop.getProperty("email"));
		log.typepassword(prop.getProperty("password"));
		log.clickbtn();
		log.clickbtn2();
	}
	
	public void CreateAccount()
	{
		log.typename(prop.getProperty("name"));
		log.typeyouremail(prop.getProperty("youremail"));
		log.typeyourpassword(prop.getProperty("yourpassword"));
		log.typepasswordagain(prop.getProperty("passagain"));
		log.Clickbtn3(); 
	}
	
	public void ordersModule() {
		log.checkCancelled();
		log.checkbuyagain();
		log.Checknotyetshipped();
		
		
	}
	public void addAddress() {
		log.enterhouseno(prop.getProperty("houseno"));
		log.typepostalcode(prop.getProperty("postalcode"));
		log.typemobilenumber(prop.getProperty("mobilenumber"));
		log.Selectcity(prop.getProperty("city"));
	}
	
	
	}
	
	
	
	
	
		
		

		
		
		
		
		
		
	

		
	

