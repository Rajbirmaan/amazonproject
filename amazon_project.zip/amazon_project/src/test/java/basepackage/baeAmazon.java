package basepackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import utility.Timeutils;

public class baeAmazon {
	
public static	Properties prop = new Properties();
	
public static	WebDriver driver;
	
	public baeAmazon() {
		
		try {
			
			FileInputStream file = new FileInputStream("C:\\Users\\Dell\\eclipse-workspace\\amazon_project\\src\\test\\java\\evironmentVariables\\config.properties");
		prop.load(file);
		
	}
		catch(FileNotFoundException e)
		{
			e.printStackTrace(); //to print
			
		}
		catch(IOException a) {
		a.printStackTrace(); //To print
		}
		}
	
  public static void initiate() {
	String browsername=prop.getProperty("browser"); //get prop from config and store in variable
	
	if (browsername.equals("chrome")) {
		System.setProperty("Webdriver.chrome.driver", "chrome.exe");
	
	driver= new ChromeDriver();
			}
	
	else if(browsername.equals("firefox")) {
		System.setProperty("WebDriver.gecko.driver", "geckoDriver.exe");
		driver=new FirefoxDriver();
			
		
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(Timeutils.timepage, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url")); //read from config.properties
	}
	}
	
			
		

	
	}

	


		// TODO Auto-generated method stub
		
	

