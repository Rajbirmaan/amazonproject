package utility;

public class Timeutils {
	public static int timepage=20;

}
